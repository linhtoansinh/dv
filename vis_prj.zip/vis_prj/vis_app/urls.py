from django.urls import path
from .views import *
urlpatterns = [
    #path('admin/', admin.site.urls),
    path('graph_total_income/', graph_total_income),
    path('api/total_income', total_income, name = 'total_income'),
    path('graph_success/', graph_success),
    path('api/success', success, name = 'success'),
    path('graph_ABC_income/', graph_ABC_income),
    path('api/ABC_income', ABC_income, name = 'ABC_income'),
]