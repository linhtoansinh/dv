from django.db import models

class CuaHang(models.Model):
    storeID = models.CharField(max_length=10)
    #tenCH = models.CharField(max_length=100)
    #ngayThamGia = models.DateTimeField(auto_now_add=True)
    #diaChi = models.CharField(max_length=100)
    #SDT = models.CharField(max_length=11)
    #email = models.CharField(max_length=56)
    THU_PHI = [('T', 'Thang'), ('D', 'Don')]
    loaiCH = models.CharField(max_length=1, default='D', choices=THU_PHI)
    #activated = models.BooleanField(default=True)

class HoaDon(models.Model):
    maHD = models.CharField(max_length=10)
    # ngayLap = models.DateTimeField(auto_now_add=True)
    # phiShip = models.FloatField()
    tongTien = models.FloatField()
    account_CH = models.ForeignKey(to=CuaHang, on_delete=models.CASCADE)
    # account_KH = 1

class HoaDonGiaoHang(models.Model):
    maHD = models.ForeignKey(to=HoaDon, on_delete=models.CASCADE)
    # nhanDon = models.DateTimeField(auto_now_add=True)
    # tienCong = models.FloatField()
    trangThai = models.BooleanField(default=False)

# class LichSuGiaoHang(models.Model):
#     maHD = models.ForeignKey(to=HoaDon, on_delete=models.CASCADE)
#     thoiGian = models.DateTimeField()
#     trangThai = models.CharField(max_length=10)
#     ghiChu = models.CharField(max_length=10)