from django.contrib import admin
from vis_app.models import CuaHang, HoaDon, HoaDonGiaoHang


admin.site.register(CuaHang)
admin.site.register(HoaDon)
admin.site.register(HoaDonGiaoHang)